package com.varsitycollege.upskill2.ui

data class PaymentMethod(
    val cardNumber: String,
    val expiryDate: String,
    val cvv: String
)