package com.varsitycollege.upskill2.ui.contactus;

import androidx.fragment.app.Fragment;

public class ContacUsFragment extends Fragment {
}
