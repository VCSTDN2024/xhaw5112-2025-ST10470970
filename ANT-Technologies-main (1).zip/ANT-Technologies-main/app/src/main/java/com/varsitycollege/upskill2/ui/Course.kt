package com.varsitycollege.upskill2.ui

data class Course(
    val id: Int,
    val name: String,
    val description: String,
    val price: Double
)
